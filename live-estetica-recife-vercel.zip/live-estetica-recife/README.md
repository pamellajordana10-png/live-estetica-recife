# Live Estética Recife — Site para Vercel

Site estático (HTML único). Sem build, sem dependências.

## Como publicar na Vercel (2 minutos)

### Opção A — Pelo site da Vercel (mais fácil, sem instalar nada)
1. Acesse https://vercel.com/new
2. Faça login (pode usar GitHub / Google / e-mail)
3. Clique em **Add New > Project** > **Deploy** via upload? 
   - Se não aparecer upload direto: crie um repositório no GitHub com estes arquivos e importe.
4. Alternativa direta: arraste a pasta `live-vercel` no painel de deploy da Vercel (quando disponível) ou use a CLI abaixo.

### Opção B — Pela CLI (recomendado)
```bash
# 1. Instale a CLI (uma vez)
npm i -g vercel

# 2. Entre na pasta do projeto
cd live-vercel

# 3. Faça login e publique
vercel login
vercel --prod
```
Responda:
- Set up and deploy? **Y**
- Which scope? **seu usuário**
- Link to existing project? **N**
- Project name? **live-estetica-recife** (ou outro)
- Directory? **./** (Enter)
- Override settings? **N**

No final a Vercel mostra a URL, ex: https://live-estetica-recife.vercel.app

### Opção C — Via GitHub
1. Crie um repositório novo no GitHub chamado `live-estetica-recife`
2. Suba os arquivos desta pasta (`index.html` + `vercel.json`)
3. Em https://vercel.com/new > **Import Git Repository** > escolha o repositório > **Deploy**
4. Pronto. Cada push no GitHub atualiza o site automaticamente.

## Domínio próprio (opcional)
Vercel > Projeto > Settings > Domains > adicione ex: www.liveesteticarecife.com.br
Depois aponte o DNS no seu provedor conforme a Vercel indicar.

## Editar depois
- Para trocar o link do Google Avaliações: abra `index.html`, procure por `URL_DO_GOOGLE` e substitua pela URL real do perfil.
- Para trocar WhatsApp/telefone/endereço: procure no `index.html` por `5581992949242` / `(81) 99294-9242`.

## Arquivos
- `index.html` — site completo
- `vercel.json` — configuração da Vercel (site estático)
